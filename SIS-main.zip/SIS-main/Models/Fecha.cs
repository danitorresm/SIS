namespace SIS.Models
{
    public class Fecha
    {
        public string? Mensaje { get; set; }
    }

}