namespace SIS.Models{
    public class ModeloNuevo{
        public Register? Register {get;set;}

        public Employe? Employe {get;set;}
    }
}