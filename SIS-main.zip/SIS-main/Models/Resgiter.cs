using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace SIS.Models
        {
          public class Register
          {
            public int Id {get; set;}            
            public DateTime? HoraEntrada {get; set;}            
            public DateTime? HoraSalida {get; set;}
            public DateOnly? Fecha {get; set;}
            public List<Employe>? Employees { get; set; }
          }
        }